//
//  NewsViewController.h
//  AbridgeMe
//
//  Created by Mackintosh on 24/06/14.
//  Copyright (c) 2014 panaceatek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsViewController : UIViewController
{
    
    NSString *webLink;
    
}
@property(nonatomic,strong) NSString *webLink;
@property(nonatomic,strong)NSString* flag;
@end
