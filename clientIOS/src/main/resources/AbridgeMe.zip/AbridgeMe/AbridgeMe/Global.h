//
//  Global.h
//  VoucherCloud
//
//  Created by Mackintosh on 22/02/14.
//  Copyright (c) 2014 Panacea. All rights reserved.
//

NSString *GlobalUserID,*GlobalUserImage,*GlobalUserEmailId,*GlobalUserName,*GlobalUserLastName,*GlobalTwitterUsername;
NSString *str_ServerUnderMaintainess;
NSString *GlobalUserLatitude;
NSString *GlobalUserLongitude;
NSUserDefaults *Global_defaults;
NSString *Global_loginStatus;
NSString *str_Tag_SearchFlag;
NSString *regFlag,*imgStr_Flag;
NSArray *userData;

BOOL twitterFlag;
NSString *strTwitterUserName;
NSString *strTwitterID;
